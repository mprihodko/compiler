jQuery(document).ready(function($){
	$("#compiler-set-up button").click(function(){
		$("body").waiting({ fixed: true });
	});
});